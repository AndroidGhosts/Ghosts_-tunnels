package com.androidghosts.dnsttghosts

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.net.VpnService

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        if (AppSettings.boot(ctx) && VpnService.prepare(ctx) == null && Profiles.selected(ctx) != null) {
            GhostVpnService.start(ctx)
        }
    }
}
