package com.androidghosts.dnsttghosts

import android.content.Intent
import android.os.Bundle
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.widget.NestedScrollView
import com.google.android.material.appbar.MaterialToolbar
import com.google.android.material.button.MaterialButton
import com.google.android.material.checkbox.MaterialCheckBox
import com.google.android.material.card.MaterialCardView

/** Selects existing independent profiles for one multi-tunnel VPN session. */
class MultiTunnelActivity : AppCompatActivity() {
    private lateinit var container: LinearLayout
    private val checks = linkedMapOf<String, MaterialCheckBox>()

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_simple)
        val toolbar = findViewById<MaterialToolbar>(R.id.toolbar)
        toolbar.title = getString(R.string.multi_tunnels)
        setSupportActionBar(toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        toolbar.setNavigationOnClickListener { finish() }
        container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), 0, dp(20), dp(48))
        }
        findViewById<android.widget.FrameLayout>(R.id.content).addView(
            NestedScrollView(this).apply { addView(container) }
        )
        render()
    }

    private fun render() {
        val profiles = Profiles.list(this)
        val selected = AppSettings.multiProfileIds(this)
        val form = Form(this, container)
        form.section(R.string.multi_general)
        form.note(getString(R.string.multi_select_help))
        form.note(getString(R.string.multi_selected_count, selected.size))

        if (profiles.isEmpty()) {
            form.note(getString(R.string.multi_no_profiles))
        } else {
            profiles.forEach { profile ->
                val id = profile.optString("id")
                val card = MaterialCardView(this).apply {
                    radius = dp(14).toFloat()
                    layoutParams = LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
                    ).apply { topMargin = dp(8) }
                }
                val box = MaterialCheckBox(this).apply {
                    text = Profiles.displayName(this@MultiTunnelActivity, profile)
                    isChecked = selected.contains(id)
                    setPadding(dp(12), dp(8), dp(12), dp(8))
                    setOnCheckedChangeListener { button, checked ->
                        if (checked && checks.values.count { it.isChecked } > 5) {
                            button.isChecked = false
                            toast(getString(R.string.multi_max_profiles))
                        }
                    }
                }
                val detail = TextView(this).apply {
                    text = "${profile.optString("domain")}  •  ${profile.optString("transport", "udp").uppercase()}"
                    textSize = 12f
                    setTextColor(getColor(R.color.text_secondary))
                    setPadding(dp(52), 0, dp(12), dp(10))
                }
                val column = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
                column.addView(box)
                column.addView(detail)
                card.addView(column)
                container.addView(card)
                checks[id] = box
            }
        }

        val edit = MaterialButton(this).apply {
            text = getString(R.string.multi_create_profile)
            setOnClickListener { startActivity(Intent(this@MultiTunnelActivity, ProfileEditActivity::class.java)) }
        }
        container.addView(edit)
        val save = MaterialButton(this).apply {
            text = getString(R.string.save)
            setOnClickListener { saveSelection() }
        }
        container.addView(save)
    }

    private fun saveSelection() {
        val ids = checks.filterValues { it.isChecked }.keys.toSet()
        if (ids.isEmpty()) {
            AppSettings.saveMultiProfileIds(this, emptySet())
            toast(getString(R.string.multi_disabled))
            finish()
            return
        }
        AppSettings.saveMultiProfileIds(this, ids.take(5).toSet())
        toast(getString(R.string.multi_selection_saved, ids.size.coerceAtMost(5)))
        finish()
    }
}
