package com.androidghosts.dnsttghosts

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.util.AttributeSet
import android.view.View
import kotlin.math.max

class TrafficChartView @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null
) : View(context, attrs) {
    private data class Sample(val up: Float, val down: Float, val rtt: Float)
    private val history = ArrayDeque<Sample>()
    private var fullSession = false
    private val gridPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0x30FFFFFF; strokeWidth = 1f }
    private val labelPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xCCFFFFFF.toInt(); textSize = 11f }
    private val upPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF00E5A0.toInt(); style = Paint.Style.STROKE; strokeWidth = 3f }
    private val downPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF9B7BFF.toInt(); style = Paint.Style.STROKE; strokeWidth = 3f }
    private val pingPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFFFFC857.toInt(); style = Paint.Style.STROKE; strokeWidth = 3f }

    fun setFullSession(enabled: Boolean) {
        fullSession = enabled
        invalidate()
    }

    fun push(upload: Long, download: Long, rttMs: Long = 0) {
        history.addLast(Sample(upload.coerceAtLeast(0).toFloat(), download.coerceAtLeast(0).toFloat(), rttMs.coerceAtLeast(0).toFloat()))
        // Keep a bounded in-memory history while retaining the whole session timeline by decimating old samples.
        if (history.size > 20_000) {
            val compact = ArrayDeque<Sample>()
            history.forEachIndexed { index, sample -> if (index % 2 == 0) compact.addLast(sample) }
            history.clear()
            history.addAll(compact)
        }
        postInvalidate()
    }

    fun clear() { history.clear(); invalidate() }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        if (width <= 0 || height <= 0 || history.isEmpty()) return
        val visible = if (fullSession || history.size <= 300) history.toList() else history.takeLast(300)
        val panelH = height.toFloat() / 3f
        val left = 34f
        val plots = listOf(
            Triple(visible.map { it.down }, downPaint, "↓"),
            Triple(visible.map { it.up }, upPaint, "↑"),
            Triple(visible.map { it.rtt }, pingPaint, "RTT")
        )
        plots.forEachIndexed { index, (values, paint, label) ->
            val top = index * panelH
            val bottom = top + panelH
            canvas.drawLine(0f, bottom, width.toFloat(), bottom, gridPaint)
            canvas.drawLine(left, top + 2f, left, bottom - 2f, gridPaint)
            canvas.drawText(label, 3f, top + panelH * .58f, labelPaint)
            drawSeries(canvas, values, paint, max(1f, values.maxOrNull() ?: 0f), left, top, panelH)
        }
    }

    private fun drawSeries(canvas: Canvas, values: List<Float>, paint: Paint, maxValue: Float, left: Float, top: Float, panelH: Float) {
        if (values.size < 2) return
        val right = width.toFloat() - 2f
        val plotW = max(1f, right - left)
        val step = plotW / (values.size - 1).toFloat()
        val path = Path()
        values.forEachIndexed { index, value ->
            val x = left + index * step
            val y = top + panelH - 3f - (value / maxValue) * (panelH - 7f)
            if (index == 0) path.moveTo(x, y) else path.lineTo(x, y)
        }
        canvas.drawPath(path, paint)
    }
}
