package com.androidghosts.dnsttghosts

import android.content.Context
import android.net.Uri
import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

object Profiles {
    private const val PREFS = "profiles"
    private const val KEY_LIST = "list"
    private const val KEY_SELECTED = "selected"
    const val LINK_SCHEME = "dnstt-ghosts://"

    fun defaults(): JSONObject = JSONObject().apply {
        put("id", UUID.randomUUID().toString())
        put("name", "")
        put("protocol", "dnstt")
        put("domain", "")
        put("pubkey", "")
        put("transport", "udp")
        put("resolvers", JSONArray(listOf("8.8.8.8:53")))
        put("resolverStrategy", "roundrobin")
        put("remoteDns", "8.8.8.8:53")
        put("utls", "Chrome_120")
        put("dohSenders", 32)
        put("segmentSize", 0)
        put("fragment", JSONObject().apply {
            put("enabled", false); put("minSize", 1); put("maxSize", 5); put("delayMs", 5); put("packets", 1)
        })
        put("mode", "socks")
        put("socksUser", ""); put("socksPass", ""); put("socksFast", true)
        put("sshUser", ""); put("sshPass", ""); put("sshKey", ""); put("sshKeyPass", ""); put("sshHostKey", "")
        put("localSocks", "127.0.0.1:1080")
        put("localSocksUser", ""); put("localSocksPass", "")
        put("localHttp", "")
        put("localForward", "127.0.0.1:7000")
        put("dnsCache", true)
        put("pollMinMs", 500); put("pollMaxMs", 10000)
        put("kcpWindow", 0); put("kcpNoDelay", false); put("kcpIntervalMs", 100); put("kcpResend", 0)
        put("smuxBufferKB", 1024)
        put("idleTimeoutSec", 120); put("keepAliveSec", 10); put("reconnectSec", 3)
    }

    /** Fill missing keys from defaults so old/imported profiles get every field. */
    fun normalize(p: JSONObject): JSONObject {
        val d = defaults()
        val out = JSONObject(d.toString())
        p.keys().forEach { k -> out.put(k, p.get(k)) }
        val frag = d.getJSONObject("fragment")
        p.optJSONObject("fragment")?.let { f -> f.keys().forEach { frag.put(it, f.get(it)) } }
        out.put("fragment", frag)
        if (out.optString("id").isEmpty()) out.put("id", UUID.randomUUID().toString())
        return out
    }

    private fun prefs(ctx: Context) = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun list(ctx: Context): MutableList<JSONObject> {
        val arr = JSONArray(prefs(ctx).getString(KEY_LIST, "[]"))
        return (0 until arr.length()).map { normalize(arr.getJSONObject(it)) }.toMutableList()
    }

    private fun saveList(ctx: Context, list: List<JSONObject>) {
        prefs(ctx).edit().putString(KEY_LIST, JSONArray(list).toString()).apply()
    }

    fun get(ctx: Context, id: String?): JSONObject? = list(ctx).firstOrNull { it.optString("id") == id }

    fun save(ctx: Context, p: JSONObject) {
        val list = list(ctx)
        val i = list.indexOfFirst { it.optString("id") == p.optString("id") }
        if (i >= 0) list[i] = p else list.add(p)
        saveList(ctx, list)
        if (selectedId(ctx) == null) select(ctx, p.optString("id"))
    }

    fun delete(ctx: Context, id: String) {
        saveList(ctx, list(ctx).filter { it.optString("id") != id })
        if (selectedId(ctx) == id) prefs(ctx).edit().remove(KEY_SELECTED).apply()
    }

    fun duplicate(ctx: Context, p: JSONObject): JSONObject {
        val c = JSONObject(p.toString())
        c.put("id", UUID.randomUUID().toString())
        c.put("name", p.optString("name") + " (2)")
        save(ctx, c)
        return c
    }

    fun selectedId(ctx: Context): String? = prefs(ctx).getString(KEY_SELECTED, null)
    fun select(ctx: Context, id: String) = prefs(ctx).edit().putString(KEY_SELECTED, id).apply()
    fun selected(ctx: Context): JSONObject? = get(ctx, selectedId(ctx)) ?: list(ctx).firstOrNull()

    fun toLink(p: JSONObject): String {
        val c = fullExport(p)
        return LINK_SCHEME + Base64.encodeToString(c.toString().toByteArray(), Base64.URL_SAFE or Base64.NO_WRAP or Base64.NO_PADDING)
    }

    fun toSafeJson(p: JSONObject): String = fullExport(p).toString(2)

    private fun fullExport(p: JSONObject): JSONObject {
        val c = JSONObject(p.toString())
        c.remove("id")
        // Full export intentionally preserves sshPass, socksPass, sshKeyPass and
        // all other credentials so copy/share/import is lossless.
        return c
    }

    /** Parse dnstt links/JSON, OpenVPN text, or Hysteria URI links. */
    fun parse(text: String): JSONObject? {
        val t = text.trim()
        return try {
            if (t.startsWith("hysteria://") || t.startsWith("hysteria2://")) {
                return parseHysteriaUri(t)
            }
            if (t.contains("<ca>") || t.contains("\nremote ") || t.startsWith("client\n")) {
                return defaults().apply {
                    put("id", UUID.randomUUID().toString())
                    put("protocol", "openvpn")
                    put("name", "OpenVPN")
                    put("ovpn", t)
                }
            }
            val json = when {
                t.startsWith("{") -> t
                t.startsWith(LINK_SCHEME) || t.startsWith("dnstt://") ->
                    String(Base64.decode(t.substringAfter("://").substringBefore("#"), Base64.URL_SAFE or Base64.NO_WRAP))
                else -> return null
            }
            val p = normalize(JSONObject(json))
            p.put("id", UUID.randomUUID().toString())
            when (p.optString("protocol", "dnstt")) {
                "dnstt" -> if (p.optString("domain").isEmpty() || p.optString("pubkey").isEmpty()) null else p
                "openvpn" -> if (p.optString("ovpn").isEmpty()) null else p
                "hysteria", "hysteria2" -> if (p.optString("server").isEmpty()) null else p
                else -> null
            }
        } catch (e: Exception) {
            null
        }
    }

    private fun parseHysteriaUri(link: String): JSONObject {
        val uri = Uri.parse(link)
        val protocol = if (link.startsWith("hysteria2://")) "hysteria2" else "hysteria"
        val host = uri.host ?: return defaults().apply { put("protocol", protocol) }
        val port = if (uri.port > 0) uri.port else 443
        return defaults().apply {
            put("id", UUID.randomUUID().toString())
            put("protocol", protocol)
            put("name", host)
            put("server", "$host:$port")
            put("auth", uri.userInfo?.substringAfter(':', uri.userInfo ?: "") ?: "")
            put("sni", uri.getQueryParameter("sni") ?: host)
            put("insecure", uri.getQueryParameter("insecure") == "1" || uri.getQueryParameter("insecure") == "true")
            uri.getQueryParameter("obfs-password")?.let { put("obfsPassword", it) }
        }
    }

    fun displayName(ctx: Context, p: JSONObject): String =
        p.optString("name").ifEmpty { p.optString("domain").ifEmpty { ctx.getString(R.string.unnamed) } }
}

object AppSettings {
    private fun p(ctx: Context) = ctx.getSharedPreferences("settings", Context.MODE_PRIVATE)
    fun proxyOnly(ctx: Context) = p(ctx).getBoolean("proxy_only", false)
    fun ipv6(ctx: Context) = p(ctx).getBoolean("ipv6", true)
    fun blockIpv6(ctx: Context) = p(ctx).getBoolean("block_ipv6", false)
    fun bypassLan(ctx: Context) = p(ctx).getBoolean("bypass_lan", true)
    fun tunMtu(ctx: Context) = p(ctx).getInt("tun_mtu", 1500)
    fun autoDns(ctx: Context) = p(ctx).getBoolean("auto_dns", true)
    fun tunnelDnsServers(ctx: Context): List<String> = p(ctx)
        .getString("tunnel_dns", "8.8.8.8")!!
        .split(',', '\n', ' ', '\t')
        .map { it.trim() }
        .filter { it.isNotEmpty() }
        .distinct()

    /** First configured DNS endpoint for the core's host:port field. */
    fun tunnelDns(ctx: Context): String {
        val value = tunnelDnsServers(ctx).firstOrNull() ?: "8.8.8.8"
        return if (value.count { it == ':' } == 1 || value.startsWith("[") && value.contains("]:")) {
            value
        } else {
            "$value:53"
        }
    }
    fun tunnelDnsCache(ctx: Context) = p(ctx).getBoolean("tunnel_dns_cache", true)
    fun dnsCacheTtlSeconds(ctx: Context) = p(ctx).getInt("dns_cache_ttl_seconds", 120)
    fun dnsCacheMaxEntries(ctx: Context) = p(ctx).getInt("dns_cache_max_entries", 2048)
    fun tcpNoDelay(ctx: Context) = p(ctx).getBoolean("tcp_no_delay", false)
    fun payloadClientKB(ctx: Context) = p(ctx).getInt("payload_client_kb", 16384)
    fun payloadRemoteKB(ctx: Context) = p(ctx).getInt("payload_remote_kb", 32768)
    fun pingHost(ctx: Context) = p(ctx).getString("ping_host", "1.1.1.1")!!
    fun pingProtocol(ctx: Context): String = p(ctx).getString("ping_protocol", "http")!!
        .takeIf { it in setOf("udp", "http", "dns", "ssl") } ?: "http"
    fun pingIntervalSec(ctx: Context) = p(ctx).getInt("ping_interval_sec", 10)
    fun pingTimeoutMs(ctx: Context) = p(ctx).getInt("ping_timeout_ms", 3000)
    fun multiCount(ctx: Context) = p(ctx).getInt("multi_count", 1)
    fun multiProfiles(ctx: Context): JSONArray = runCatching { JSONArray(p(ctx).getString("multi_profiles", "[]")) }.getOrDefault(JSONArray())
    fun multiProfileIds(ctx: Context): Set<String> = p(ctx).getStringSet("multi_profile_ids", emptySet()) ?: emptySet()
    fun selectedMultiProfiles(ctx: Context): List<JSONObject> = multiProfileIds(ctx)
        .mapNotNull { id -> Profiles.get(ctx, id) }
        .take(5)
    fun splitMode(ctx: Context) = p(ctx).getString("split_mode", "all")!!
    fun splitApps(ctx: Context): Set<String> = p(ctx).getStringSet("split_apps", emptySet())!!
    fun boot(ctx: Context) = p(ctx).getBoolean("boot", false)
    fun edit(ctx: Context) = p(ctx).edit()
    fun saveMulti(ctx: Context, count: Int, profiles: JSONArray) = p(ctx).edit()
        .putInt("multi_count", count.coerceIn(1, 5))
        .putString("multi_profiles", profiles.toString())
        .apply()
    fun saveMultiProfileIds(ctx: Context, ids: Set<String>) = p(ctx).edit()
        .putStringSet("multi_profile_ids", ids.take(5).toSet())
        .putInt("multi_count", ids.size.coerceIn(1, 5))
        .apply()
}
