package com.androidghosts.dnsttghosts

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import ghostcore.Ghostcore
import ghostcore.Logger
import java.util.concurrent.CopyOnWriteArrayList
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class App : Application() {
    override fun onCreate() {
        super.onCreate()
        instance = this
        Ghostcore.setLogger(object : Logger {
            override fun log(line: String) = LogBuffer.add(line)
        })
        if (Build.VERSION.SDK_INT >= 26) {
            val ch = NotificationChannel(CHANNEL, getString(R.string.notif_channel), NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(ch)
        }
    }

    companion object {
        const val CHANNEL = "vpn"
        lateinit var instance: App
            private set
    }
}

object LogBuffer {
    private const val MAX = 3000
    private val lines = ArrayDeque<String>()
    private val listeners = CopyOnWriteArrayList<(String) -> Unit>()
    private val main = Handler(Looper.getMainLooper())
    private var lastKey = ""
    private var lastAt = 0L
    private var repeats = 0

    fun add(line: String) {
        val clean = line.trim().ifEmpty { return }
        val key = clean.replace(Regex("\\d+"), "#")
        val now = System.currentTimeMillis()
        synchronized(lines) {
            if (key == lastKey && now - lastAt < 3000) {
                repeats++
                lastAt = now
                return
            }
            if (repeats > 0) {
                lines.addLast("${SimpleDateFormat("HH:mm:ss", Locale.US).format(Date())}  WARN  previous event repeated $repeats times")
                repeats = 0
            }
            lastKey = key; lastAt = now
        }
        val level = when {
            clean.contains("error", true) || clean.contains("failed", true) -> "ERROR"
            clean.contains("warn", true) || clean.contains("retry", true) -> "WARN"
            else -> "INFO"
        }
        val stamp = SimpleDateFormat("HH:mm:ss", Locale.US).format(Date())
        val formatted = "$stamp  $level  $clean"
        synchronized(lines) {
            lines.addLast(formatted)
            while (lines.size > MAX) lines.removeFirst()
        }
        main.post { listeners.forEach { it(formatted) } }
    }

    fun all(): String = synchronized(lines) { lines.joinToString("\n") }
    fun clear() = synchronized(lines) { lines.clear() }
    fun listen(l: (String) -> Unit) = listeners.add(l)
    fun unlisten(l: (String) -> Unit) = listeners.remove(l)
}
