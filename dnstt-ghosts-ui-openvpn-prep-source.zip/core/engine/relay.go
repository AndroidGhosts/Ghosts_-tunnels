package engine

import (
	"io"
	"net"
	"sync"
	"sync/atomic"
)

type closeWriter interface{ CloseWrite() error }
type closeReader interface{ CloseRead() error }

// relay copies bidirectionally between a and b until both directions finish.
func relay(a, b net.Conn, s *Stats) {
	atomic.AddInt64(&s.ActiveConns, 1)
	atomic.AddInt64(&s.TotalConns, 1)
	defer atomic.AddInt64(&s.ActiveConns, -1)
	var wg sync.WaitGroup
	wg.Add(2)
	pipe := func(dst, src net.Conn) {
		defer wg.Done()
		io.Copy(dst, src)
		if cw, ok := dst.(closeWriter); ok {
			cw.CloseWrite()
		} else {
			dst.Close()
		}
		if cr, ok := src.(closeReader); ok {
			cr.CloseRead()
		}
	}
	go pipe(a, b)
	go pipe(b, a)
	wg.Wait()
	a.Close()
	b.Close()
}
