package engine

import (
	"crypto/sha256"
	"encoding/base64"
	"fmt"
	"log"
	"net"
	"strings"
	"time"

	"golang.org/x/crypto/ssh"
)

func (t *Tunnel) ssh() (*ssh.Client, error) {
	t.sshMu.Lock()
	defer t.sshMu.Unlock()
	if t.sshCli != nil {
		return t.sshCli, nil
	}
	stream, err := t.OpenStream()
	if err != nil {
		return nil, err
	}
	var auths []ssh.AuthMethod
	if strings.TrimSpace(t.cfg.SshKey) != "" {
		var signer ssh.Signer
		if t.cfg.SshKeyPass != "" {
			signer, err = ssh.ParsePrivateKeyWithPassphrase([]byte(t.cfg.SshKey), []byte(t.cfg.SshKeyPass))
		} else {
			signer, err = ssh.ParsePrivateKey([]byte(t.cfg.SshKey))
		}
		if err != nil {
			stream.Close()
			return nil, fmt.Errorf("ssh private key: %v", err)
		}
		auths = append(auths, ssh.PublicKeys(signer))
	}
	if t.cfg.SshPass != "" {
		pass := t.cfg.SshPass
		auths = append(auths, ssh.Password(pass),
			ssh.KeyboardInteractive(func(_, _ string, qs []string, _ []bool) ([]string, error) {
				ans := make([]string, len(qs))
				for i := range ans {
					ans[i] = pass
				}
				return ans, nil
			}))
	}
	pin := strings.TrimPrefix(strings.TrimSpace(t.cfg.SshHostKey), "SHA256:")
	cc := &ssh.ClientConfig{
		User:    t.cfg.SshUser,
		Auth:    auths,
		Timeout: 45 * time.Second,
		HostKeyCallback: func(_ string, _ net.Addr, key ssh.PublicKey) error {
			sum := sha256.Sum256(key.Marshal())
			fp := base64.RawStdEncoding.EncodeToString(sum[:])
			if pin != "" && pin != fp {
				return fmt.Errorf("ssh host key mismatch: got SHA256:%s", fp)
			}
			log.Printf("ssh host key SHA256:%s", fp)
			return nil
		},
	}
	stream.SetDeadline(time.Now().Add(45 * time.Second))
	conn, chans, reqs, err := ssh.NewClientConn(stream, "dnstt", cc)
	if err != nil {
		stream.Close()
		return nil, fmt.Errorf("ssh: %v", err)
	}
	stream.SetDeadline(time.Time{})
	cli := ssh.NewClient(conn, chans, reqs)
	t.sshCli = cli
	log.Printf("ssh logged in as %s (server %s)", t.cfg.SshUser, string(conn.ServerVersion()))
	go func() {
		tk := time.NewTicker(time.Duration(t.cfg.KeepAliveSec) * time.Second)
		defer tk.Stop()
		done := make(chan struct{})
		go func() { cli.Wait(); close(done) }()
		for {
			select {
			case <-done:
				t.sshMu.Lock()
				if t.sshCli == cli {
					t.sshCli = nil
				}
				t.sshMu.Unlock()
				log.Printf("ssh connection closed")
				return
			case <-tk.C:
				if _, _, err := cli.SendRequest("keepalive@openssh.com", true, nil); err != nil {
					cli.Close()
				}
			}
		}
	}()
	return cli, nil
}

func (t *Tunnel) sshDial(addr string) (net.Conn, error) {
	for i := 0; i < 2; i++ {
		cli, err := t.ssh()
		if err != nil {
			return nil, err
		}
		c, err := cli.Dial("tcp", addr)
		if err == nil {
			return c, nil
		}
		if _, ok := err.(*ssh.OpenChannelError); ok {
			return nil, err
		}
		cli.Close()
		t.sshMu.Lock()
		if t.sshCli == cli {
			t.sshCli = nil
		}
		t.sshMu.Unlock()
	}
	return nil, fmt.Errorf("ssh dial %s failed", addr)
}
