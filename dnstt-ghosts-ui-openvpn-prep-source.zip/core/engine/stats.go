package engine

import (
	"encoding/json"
	"net"
	"sync/atomic"
	"time"
)

// Stats holds live counters, all accessed atomically.
type Stats struct {
	BytesUp      int64 `json:"bytesUp"`
	BytesDown    int64 `json:"bytesDown"`
	DNSBytesUp   int64 `json:"dnsBytesUp"`
	DNSBytesDown int64 `json:"dnsBytesDown"`
	QueriesSent  int64 `json:"queriesSent"`
	QueriesRecv  int64 `json:"queriesRecv"`
	ActiveConns  int64 `json:"activeConns"`
	TotalConns   int64 `json:"totalConns"`
	DNSLookups   int64 `json:"dnsLookups"`
	Sessions     int64 `json:"sessions"`
	TunnelCount  int64 `json:"tunnelCount"`
	StartedAt    int64 `json:"startedAt"`
	MTU          int64 `json:"mtu"`
	LastRTTMs    int64 `json:"lastRttMs"`
	AvgRTTMs     int64 `json:"avgRttMs"`
	JitterMs     int64 `json:"jitterMs"`
	ProbeSent    int64 `json:"probeSent"`
	ProbeFailed  int64 `json:"probeFailed"`
}

func (s *Stats) JSON() string {
	snap := Stats{
		BytesUp:      atomic.LoadInt64(&s.BytesUp),
		BytesDown:    atomic.LoadInt64(&s.BytesDown),
		DNSBytesUp:   atomic.LoadInt64(&s.DNSBytesUp),
		DNSBytesDown: atomic.LoadInt64(&s.DNSBytesDown),
		QueriesSent:  atomic.LoadInt64(&s.QueriesSent),
		QueriesRecv:  atomic.LoadInt64(&s.QueriesRecv),
		ActiveConns:  atomic.LoadInt64(&s.ActiveConns),
		TotalConns:   atomic.LoadInt64(&s.TotalConns),
		DNSLookups:   atomic.LoadInt64(&s.DNSLookups),
		Sessions:     atomic.LoadInt64(&s.Sessions),
		TunnelCount:  atomic.LoadInt64(&s.TunnelCount),
		StartedAt:    atomic.LoadInt64(&s.StartedAt),
		MTU:          atomic.LoadInt64(&s.MTU),
		LastRTTMs:    atomic.LoadInt64(&s.LastRTTMs),
		AvgRTTMs:     atomic.LoadInt64(&s.AvgRTTMs),
		JitterMs:     atomic.LoadInt64(&s.JitterMs),
		ProbeSent:    atomic.LoadInt64(&s.ProbeSent),
		ProbeFailed:  atomic.LoadInt64(&s.ProbeFailed),
	}
	b, _ := json.Marshal(snap)
	return string(b)
}

func (s *Stats) markStart() { atomic.StoreInt64(&s.StartedAt, time.Now().UnixMilli()) }

func (s *Stats) RecordProbe(rttMs int64, ok bool) {
	atomic.AddInt64(&s.ProbeSent, 1)
	if !ok {
		atomic.AddInt64(&s.ProbeFailed, 1)
		return
	}
	previous := atomic.LoadInt64(&s.LastRTTMs)
	atomic.StoreInt64(&s.LastRTTMs, rttMs)
	avg := atomic.LoadInt64(&s.AvgRTTMs)
	if avg == 0 {
		avg = rttMs
	} else {
		avg = (avg*7 + rttMs) / 8
	}
	atomic.StoreInt64(&s.AvgRTTMs, avg)
	if previous > 0 {
		j := rttMs - previous
		if j < 0 {
			j = -j
		}
		old := atomic.LoadInt64(&s.JitterMs)
		atomic.StoreInt64(&s.JitterMs, (old*7+j)/8)
	}
}

// countConn counts bytes flowing through the tunnel.
type countConn struct {
	net.Conn
	s *Stats
}

func (c *countConn) Read(p []byte) (int, error) {
	n, err := c.Conn.Read(p)
	atomic.AddInt64(&c.s.BytesDown, int64(n))
	return n, err
}

func (c *countConn) Write(p []byte) (int, error) {
	n, err := c.Conn.Write(p)
	atomic.AddInt64(&c.s.BytesUp, int64(n))
	return n, err
}
