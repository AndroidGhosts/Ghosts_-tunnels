package engine

import (
	"encoding/json"
	"fmt"
	"net"
	"strings"
)

// Fragment configures TLS ClientHello segmentation for DoH/DoT.
type Fragment struct {
	Enabled bool `json:"enabled"`
	MinSize int  `json:"minSize"`
	MaxSize int  `json:"maxSize"`
	DelayMs int  `json:"delayMs"`
	Packets int  `json:"packets"`
}

// Config is the JSON configuration sent from the Android app.
type Config struct {
	// Protocol selects the backend. Existing profiles default to dnstt.
	Protocol  string   `json:"protocol"`
	Domain    string   `json:"domain"`
	Pubkey    string   `json:"pubkey"`
	Transport string   `json:"transport"` // udp | doh | dot
	Resolvers []string `json:"resolvers"`
	// Resolver selection across Resolvers: roundrobin | random | parallel
	ResolverStrategy string `json:"resolverStrategy"`
	UTLS             string `json:"utls"`
	DohSenders       int    `json:"dohSenders"`

	// Per-query payload size (0 = automatic/maximum).
	SegmentSize int      `json:"segmentSize"`
	Fragment    Fragment `json:"fragment"`

	PollMinMs int `json:"pollMinMs"`
	PollMaxMs int `json:"pollMaxMs"`

	KcpWindow             int  `json:"kcpWindow"`
	KcpNoDelay            bool `json:"kcpNoDelay"`
	KcpIntervalMs         int  `json:"kcpIntervalMs"`
	KcpResend             int  `json:"kcpResend"`
	SmuxBufferKB          int  `json:"smuxBufferKB"`
	PayloadClientBufferKB int  `json:"payloadClientBufferKB"`
	PayloadRemoteBufferKB int  `json:"payloadRemoteBufferKB"`
	IdleTimeoutSec        int  `json:"idleTimeoutSec"`
	KeepAliveSec          int  `json:"keepAliveSec"`

	Mode string `json:"mode"` // socks | ssh | forward

	SocksUser string `json:"socksUser"`
	SocksPass string `json:"socksPass"`
	SocksFast bool   `json:"socksFast"`

	SshUser    string `json:"sshUser"`
	SshPass    string `json:"sshPass"`
	SshKey     string `json:"sshKey"`
	SshKeyPass string `json:"sshKeyPass"`
	SshHostKey string `json:"sshHostKey"` // optional SHA256 fingerprint to pin
	TCPNoDelay bool   `json:"tcpNoDelay"`

	LocalSocks     string `json:"localSocks"`
	LocalForward   string `json:"localForward"`
	LocalSocksUser string `json:"localSocksUser"`
	LocalSocksPass string `json:"localSocksPass"`
	LocalHTTP      string `json:"localHttp"`

	RemoteDNS          string `json:"remoteDns"`
	DNSCache           bool   `json:"dnsCache"`
	DNSCacheTTLSeconds int    `json:"dnsCacheTtlSeconds"`
	DNSCacheMaxEntries int    `json:"dnsCacheMaxEntries"`
	BlockIPv6          bool   `json:"blockIPv6"`
	BlockUDP           bool   `json:"blockUdp"`
	ReconnectSec       int    `json:"reconnectSec"`
}

// ParseConfig parses and validates JSON config with defaults.
func ParseConfig(s string) (*Config, error) {
	c := &Config{}
	if err := json.Unmarshal([]byte(s), c); err != nil {
		return nil, fmt.Errorf("bad config json: %v", err)
	}
	c.Protocol = strings.ToLower(strings.TrimSpace(c.Protocol))
	if c.Protocol == "" {
		c.Protocol = "dnstt"
	}
	if c.Protocol != "dnstt" {
		return nil, fmt.Errorf("unsupported protocol %q: this build contains only the dnstt backend", c.Protocol)
	}
	c.Domain = strings.TrimSuffix(strings.TrimSpace(c.Domain), ".")
	c.Pubkey = strings.TrimSpace(c.Pubkey)
	c.Transport = strings.ToLower(strings.TrimSpace(c.Transport))
	if c.Transport != "doh" && c.Transport != "dot" && c.Transport != "udp" {
		c.Transport = "udp"
	}
	if c.Transport == "" {
		c.Transport = "doh"
	}
	if c.Domain == "" {
		return nil, fmt.Errorf("domain is required")
	}
	if c.Pubkey == "" {
		return nil, fmt.Errorf("server public key is required")
	}
	var rs []string
	for _, r := range c.Resolvers {
		for _, part := range strings.FieldsFunc(r, func(r rune) bool { return r == '\n' || r == ',' || r == ' ' }) {
			if part = strings.TrimSpace(part); part != "" {
				rs = append(rs, normalizeResolver(c.Transport, part))
			}
		}
	}
	if len(rs) == 0 {
		return nil, fmt.Errorf("at least one resolver is required")
	}
	c.Resolvers = rs
	if c.ResolverStrategy == "" {
		c.ResolverStrategy = "roundrobin"
	}
	if c.ResolverStrategy != "roundrobin" && c.ResolverStrategy != "random" && c.ResolverStrategy != "parallel" {
		return nil, fmt.Errorf("unsupported resolver strategy %q", c.ResolverStrategy)
	}
	if c.UTLS == "" {
		c.UTLS = "Chrome_120"
	}
	if c.DohSenders <= 0 {
		c.DohSenders = 32
	}
	if c.KcpIntervalMs <= 0 {
		c.KcpIntervalMs = 100
	}
	if c.KcpResend < 0 {
		c.KcpResend = 0
	}
	if c.KcpWindow < 0 {
		c.KcpWindow = 0
	}
	if c.Mode == "" {
		c.Mode = "socks"
	}
	if c.TCPNoDelay {
		c.KcpNoDelay = true
	}
	if c.LocalSocks == "" {
		c.LocalSocks = "127.0.0.1:1080"
	}
	if c.LocalForward == "" {
		c.LocalForward = "127.0.0.1:7000"
	}
	if c.RemoteDNS == "" {
		c.RemoteDNS = resolverTCPAddress(c.Resolvers[0])
	}
	if host, port, err := net.SplitHostPort(c.RemoteDNS); err != nil || strings.TrimSpace(host) == "" || port == "" {
		return nil, fmt.Errorf("remoteDns must be host:port, got %q", c.RemoteDNS)
	}
	if c.IdleTimeoutSec <= 0 {
		c.IdleTimeoutSec = 120
	}
	if c.KeepAliveSec <= 0 {
		c.KeepAliveSec = 10
	}
	if c.DNSCacheTTLSeconds <= 0 {
		c.DNSCacheTTLSeconds = 120
	}
	if c.DNSCacheMaxEntries <= 0 {
		c.DNSCacheMaxEntries = 2048
	}
	if c.DNSCacheTTLSeconds > 86400 {
		c.DNSCacheTTLSeconds = 86400
	}
	if c.DNSCacheMaxEntries > 65536 {
		c.DNSCacheMaxEntries = 65536
	}
	if c.SmuxBufferKB <= 0 {
		c.SmuxBufferKB = 1024
	}
	if c.PayloadClientBufferKB <= 0 {
		c.PayloadClientBufferKB = c.SmuxBufferKB
	}
	if c.PayloadRemoteBufferKB <= 0 {
		c.PayloadRemoteBufferKB = c.SmuxBufferKB * 2
	}
	if c.ReconnectSec <= 0 {
		c.ReconnectSec = 3
	}
	if c.Mode == "ssh" && c.SshUser == "" {
		return nil, fmt.Errorf("ssh username is required in SSH mode")
	}
	return c, nil
}

func normalizeResolver(transport, r string) string {
	switch transport {
	case "doh":
		if !strings.Contains(r, "://") {
			r = "https://" + r
		}
		if strings.Count(r, "/") == 2 {
			r += "/dns-query"
		}
	case "dot":
		if _, _, err := net.SplitHostPort(r); err != nil {
			r = net.JoinHostPort(strings.Trim(r, "[]"), "853")
		}
	default:
		if _, _, err := net.SplitHostPort(r); err != nil {
			r = net.JoinHostPort(strings.Trim(r, "[]"), "53")
		}
	}
	return r
}

// resolverTCPAddress supplies the legacy dnstt VPN DNS forwarder from the
// profile resolver, without exposing a second custom DNS setting in the UI.
func resolverTCPAddress(r string) string {
	u := strings.TrimPrefix(strings.TrimPrefix(r, "https://"), "http://")
	u = strings.SplitN(u, "/", 2)[0]
	if host, _, err := net.SplitHostPort(u); err == nil {
		return net.JoinHostPort(host, "53")
	}
	return net.JoinHostPort(strings.Trim(u, "[]"), "53")
}
