package engine

import (
	"fmt"
	"log"
	"net"
	"sort"
	"sync"
	"sync/atomic"
)

// TunnelGroup runs independent dnstt sessions behind one VPN interface.
type TunnelGroup struct {
	tunnels []*Tunnel
	next    uint32
	mu      sync.RWMutex
	closed  bool
	stats   Stats
}

func NewTunnelGroup(configs []*Config) (*TunnelGroup, error) {
	if len(configs) < 1 || len(configs) > 5 {
		return nil, fmt.Errorf("tunnel count must be between 1 and 5")
	}
	g := &TunnelGroup{}
	for _, cfg := range configs {
		t, err := NewTunnel(cfg)
		if err != nil {
			g.Close()
			return nil, err
		}
		g.tunnels = append(g.tunnels, t)
	}
	return g, nil
}

func (g *TunnelGroup) Connect() {
	for i, t := range g.tunnels {
		log.Printf("tunnel %d/%d starting: %s via %s", i+1, len(g.tunnels), t.cfg.Domain, t.cfg.Transport)
		t.Connect()
	}
}

func (g *TunnelGroup) Dial(addr string) (net.Conn, error) {
	g.mu.RLock()
	if g.closed {
		g.mu.RUnlock()
		return nil, net.ErrClosed
	}
	tunnels := append([]*Tunnel(nil), g.tunnels...)
	g.mu.RUnlock()
	n := len(tunnels)
	if n == 0 {
		return nil, net.ErrClosed
	}
	start := int(atomic.AddUint32(&g.next, 1)-1) % n
	order := make([]int, 0, n)
	for i := 0; i < n; i++ {
		order = append(order, (start+i)%n)
	}
	sort.SliceStable(order, func(i, j int) bool {
		return tunnelScore(tunnels[order[i]]) < tunnelScore(tunnels[order[j]])
	})
	var last error
	for _, idx := range order {
		t := tunnels[idx]
		if c, err := t.Dial(addr); err == nil {
			return c, nil
		} else {
			last = err
		}
	}
	return nil, last
}

// tunnelScore is deliberately conservative: it changes only the placement of
// new flows and never migrates an existing TCP stream. Probe values are local
// to each tunnel; active connections are used as a lightweight load signal.
func tunnelScore(t *Tunnel) int64 {
	status := t.Status()
	if status == "error" || status == "stopped" {
		return 1 << 60
	}
	s := t.Stats
	rtt := atomic.LoadInt64(&s.AvgRTTMs)
	if rtt <= 0 {
		rtt = 250
	}
	loss := atomic.LoadInt64(&s.ProbeFailed)
	sent := atomic.LoadInt64(&s.ProbeSent)
	if sent > 0 {
		loss = loss * 1000 / sent
	}
	load := atomic.LoadInt64(&s.ActiveConns)
	if status != "connected" {
		return 1<<40 + rtt*10 + loss*25 + load*100
	}
	return rtt*10 + loss*25 + load*100
}

func (g *TunnelGroup) StatsRef() *Stats {
	// Keep the group snapshot in a stable object for the VPN path.
	var total Stats
	for _, t := range g.tunnels {
		s := t.Stats
		atomic.AddInt64(&total.BytesUp, atomic.LoadInt64(&s.BytesUp))
		atomic.AddInt64(&total.BytesDown, atomic.LoadInt64(&s.BytesDown))
		atomic.AddInt64(&total.DNSBytesUp, atomic.LoadInt64(&s.DNSBytesUp))
		atomic.AddInt64(&total.DNSBytesDown, atomic.LoadInt64(&s.DNSBytesDown))
		atomic.AddInt64(&total.QueriesSent, atomic.LoadInt64(&s.QueriesSent))
		atomic.AddInt64(&total.QueriesRecv, atomic.LoadInt64(&s.QueriesRecv))
		atomic.AddInt64(&total.ActiveConns, atomic.LoadInt64(&s.ActiveConns))
		atomic.AddInt64(&total.TotalConns, atomic.LoadInt64(&s.TotalConns))
		atomic.AddInt64(&total.DNSLookups, atomic.LoadInt64(&s.DNSLookups))
		atomic.AddInt64(&total.Sessions, atomic.LoadInt64(&s.Sessions))
		atomic.AddInt64(&total.TunnelCount, atomic.LoadInt64(&s.TunnelCount))
		if x := atomic.LoadInt64(&s.StartedAt); x > 0 && (total.StartedAt == 0 || x < total.StartedAt) {
			total.StartedAt = x
		}
		if x := atomic.LoadInt64(&s.MTU); x > 0 && (total.MTU == 0 || x < total.MTU) {
			total.MTU = x
		}
	}
	g.stats = total
	return &g.stats
}

func (g *TunnelGroup) RemoteDNS() string       { return g.tunnels[0].RemoteDNS() }
func (g *TunnelGroup) DNSCacheEnabled() bool   { return g.tunnels[0].DNSCacheEnabled() }
func (g *TunnelGroup) DNSCacheTTLSeconds() int { return g.tunnels[0].DNSCacheTTLSeconds() }
func (g *TunnelGroup) DNSCacheMaxEntries() int { return g.tunnels[0].DNSCacheMaxEntries() }
func (g *TunnelGroup) IPv6Blocked() bool       { return g.tunnels[0].IPv6Blocked() }
func (g *TunnelGroup) Status() string {
	connected, connecting := 0, 0
	for _, t := range g.tunnels {
		switch t.Status() {
		case "connected":
			connected++
		case "connecting", "idle":
			connecting++
		}
	}
	if connected == len(g.tunnels) {
		return "connected"
	}
	if connected > 0 {
		return fmt.Sprintf("connected (%d/%d)", connected, len(g.tunnels))
	}
	if connecting > 0 {
		return "connecting"
	}
	return "error: all tunnels unavailable"
}
func (g *TunnelGroup) Close() {
	g.mu.Lock()
	if g.closed {
		g.mu.Unlock()
		return
	}
	g.closed = true
	g.mu.Unlock()
	for _, t := range g.tunnels {
		t.Close()
	}
}
