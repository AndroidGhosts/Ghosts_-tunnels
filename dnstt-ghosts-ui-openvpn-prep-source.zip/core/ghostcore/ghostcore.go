// Package ghostcore is the gomobile-bound API used by the dnstt ghosts app.
package ghostcore

import (
	"bufio"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"log"
	"net"
	"net/http"
	"strings"
	"sync"
	"time"

	"github.com/AndroidGhosts/dnstt-ghosts/core/engine"
	"github.com/AndroidGhosts/dnstt-ghosts/core/internal/client"
	"www.bamsoftware.com/git/dnstt.git/dns"
	"www.bamsoftware.com/git/dnstt.git/noise"
)

// Logger receives log lines from the core.
type Logger interface {
	Log(line string)
}

type logWriter struct{ l Logger }

func (w logWriter) Write(p []byte) (int, error) {
	w.l.Log(strings.TrimRight(string(p), "\n"))
	return len(p), nil
}

var (
	mu    sync.Mutex
	cur   engine.Backend
	group *engine.TunnelGroup
	tun   *engine.Tun
)

// SetLogger directs all core logs to l.
func SetLogger(l Logger) {
	// The Android log buffer adds one canonical timestamp and level.
	log.SetFlags(0)
	if l == nil {
		log.SetOutput(io.Discard)
		return
	}
	log.SetOutput(logWriter{l})
}

// Version returns the core version string.
func Version() string { return "dnstt ghosts core 1.0.0" }

// Start starts the dnstt tunnel and local proxies from a JSON config.
func Start(configJSON string) error {
	mu.Lock()
	defer mu.Unlock()
	if cur != nil {
		return errors.New("already running")
	}
	cfg, err := engine.ParseConfig(configJSON)
	if err != nil {
		return err
	}
	t, err := engine.NewTunnel(cfg)
	if err != nil {
		return err
	}
	if err := t.StartListeners(); err != nil {
		t.Close()
		return err
	}
	t.Connect()
	cur = t
	log.Printf("%s started: %s via %s (%s mode)", Version(), cfg.Domain, cfg.Transport, cfg.Mode)
	return nil
}

// StartMulti starts 1-5 independent tunnel profiles behind one VPN.
func StartMulti(configJSON string) error {
	mu.Lock()
	defer mu.Unlock()
	if cur != nil {
		return errors.New("already running")
	}
	var raw []json.RawMessage
	if err := json.Unmarshal([]byte(configJSON), &raw); err != nil {
		return fmt.Errorf("bad multi config json: %v", err)
	}
	if len(raw) < 1 || len(raw) > 5 {
		return errors.New("tunnel count must be between 1 and 5")
	}
	configs := make([]*engine.Config, 0, len(raw))
	for _, item := range raw {
		cfg, err := engine.ParseConfig(string(item))
		if err != nil {
			return err
		}
		configs = append(configs, cfg)
	}
	g, err := engine.NewTunnelGroup(configs)
	if err != nil {
		return err
	}
	g.Connect()
	group = g
	cur = g
	log.Printf("%s started: %d tunnels with smart connection distribution", Version(), len(configs))
	return nil
}

// StartVpn attaches a VpnService TUN fd (ownership is transferred).
func StartVpn(fd int, mtu int) error {
	mu.Lock()
	defer mu.Unlock()
	if cur == nil {
		return errors.New("tunnel not started")
	}
	if tun != nil {
		return errors.New("vpn already attached")
	}
	x, err := engine.StartTun(cur, fd, mtu)
	if err != nil {
		return err
	}
	tun = x
	return nil
}

// Stop stops everything.
func Stop() {
	// Detach references before closing. TUN shutdown can wait for handlers that
	// call back into the backend; holding mu here used to freeze stop/status.
	mu.Lock()
	xTun, xCur := tun, cur
	tun = nil
	cur = nil
	group = nil
	mu.Unlock()
	if xTun != nil {
		xTun.Close()
	}
	if xCur != nil {
		xCur.Close()
		log.Printf("stopped")
	}
}

// IsRunning reports whether a tunnel is active.
func IsRunning() bool {
	mu.Lock()
	defer mu.Unlock()
	return cur != nil
}

// Status returns idle/connecting/connected/error: .../stopped.
func Status() string {
	mu.Lock()
	defer mu.Unlock()
	if cur == nil {
		return "stopped"
	}
	return cur.Status()
}

// Stats returns live counters as JSON.
func Stats() string {
	mu.Lock()
	defer mu.Unlock()
	if cur == nil {
		return "{}"
	}
	return cur.StatsRef().JSON()
}

// TestLatency measures an HTTP round trip to url through the tunnel, in ms.
func TestLatency(url string, timeoutMs int) (int64, error) {
	mu.Lock()
	t := cur
	mu.Unlock()
	if t == nil {
		return 0, errors.New("tunnel not running")
	}
	if url == "" {
		url = "http://www.gstatic.com/generate_204"
	}
	if timeoutMs <= 0 {
		timeoutMs = 15000
	}
	tr := &http.Transport{
		Dial:              func(_, addr string) (net.Conn, error) { return t.Dial(addr) },
		DisableKeepAlives: true,
	}
	hc := &http.Client{Transport: tr, Timeout: time.Duration(timeoutMs) * time.Millisecond}
	start := time.Now()
	resp, err := hc.Get(url)
	if err != nil {
		t.StatsRef().RecordProbe(0, false)
		return 0, err
	}
	io.Copy(io.Discard, bufio.NewReader(io.LimitReader(resp.Body, 64*1024)))
	resp.Body.Close()
	rtt := time.Since(start).Milliseconds()
	t.StatsRef().RecordProbe(rtt, true)
	return rtt, nil
}

// Fingerprints returns comma-separated uTLS fingerprint labels.
func Fingerprints() string { return strings.Join(client.Fingerprints(), ",") }

// MaxSegmentSize returns the maximum per-query payload for domain, or 0 if invalid.
func MaxSegmentSize(domain string) int {
	name, err := dns.ParseName(strings.TrimSuffix(strings.TrimSpace(domain), "."))
	if err != nil || len(name) == 0 {
		return 0
	}
	return engine.MaxPayload(name)
}

// ValidatePubkey returns "" if s is a valid server public key, else the error.
func ValidatePubkey(s string) string {
	if _, err := noise.DecodeKey(strings.TrimSpace(s)); err != nil {
		return err.Error()
	}
	return ""
}

// GenerateKeypair returns {"privkey":"..","pubkey":".."} for a new server key.
func GenerateKeypair() (string, error) {
	priv, err := noise.GeneratePrivkey()
	if err != nil {
		return "", err
	}
	b, _ := json.Marshal(map[string]string{
		"privkey": noise.EncodeKey(priv),
		"pubkey":  noise.EncodeKey(noise.PubkeyFromPrivkey(priv)),
	})
	return string(b), nil
}

// CheckConfig validates a JSON config without starting.
func CheckConfig(configJSON string) string {
	cfg, err := engine.ParseConfig(configJSON)
	if err == nil {
		_, err = engine.NewTunnel(cfg)
	}
	if err != nil {
		return fmt.Sprint(err)
	}
	return ""
}
